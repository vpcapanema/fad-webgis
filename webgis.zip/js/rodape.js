map.on('mousemove', function (e) {
  document.querySelector('footer').innerText = 
    `Coordenadas: ${e.latlng.lat.toFixed(5)}, ${e.latlng.lng.toFixed(5)} | Datum: SIRGAS 2000 | Escala: 1:25000`;
});