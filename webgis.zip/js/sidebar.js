document.addEventListener('DOMContentLoaded', () => {
  const camadaInfo = {
    'limiteEstadual': { name: 'workspace:LimiteEstadual', url: 'http://SEU_GEOSERVER/geoserver/ows' },
    'favorabilidadeTrechos': { name: 'workspace:FavorabilidadeTrechos', url: 'http://SEU_GEOSERVER/geoserver/ows' },
    'malhaDER': { name: 'workspace:MalhaDER2024', url: 'http://SEU_GEOSERVER/geoserver/ows' },
    'limiteRegional': { name: 'workspace:LimiteRegionais', url: 'http://SEU_GEOSERVER/geoserver/ows' }
  };

  for (const camadaId in camadaInfo) {
    const checkbox = document.getElementById(camadaId);
    checkbox.addEventListener('change', () => {
      const info = camadaInfo[camadaId];
      if (checkbox.checked) {
        layers[camadaId] = L.tileLayer.wms(info.url, {
          layers: info.name,
          format: 'image/png',
          transparent: true,
          attribution: 'GeoServer FAD'
        }).addTo(map);
      } else {
        if (layers[camadaId]) {
          map.removeLayer(layers[camadaId]);
          delete layers[camadaId];
        }
      }
    });
  }
});