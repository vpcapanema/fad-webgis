map.on('mousemove', function (e) {
  document.getElementById('coords').innerText = `Lat: ${e.latlng.lat.toFixed(5)} Lon: ${e.latlng.lng.toFixed(5)}`;
});

setInterval(() => {
  const now = new Date();
  const dataHora = now.toLocaleString('pt-BR');
  document.getElementById('dataHora').innerText = `Atualizado em: ${dataHora}`;
}, 60000);