document.addEventListener('DOMContentLoaded', () => {
  const grupos = {
    'Áreas Protegidas': {
      'Terras Indígenas': 'workspace:TerrasIndigenas',
      'UC Proteção Integral': 'workspace:UC_Protecao_Integral'
    },
    'Bases Administrativas': {
      'Brasil UF': 'workspace:BrasilUF',
      'Limite Estadual': 'workspace:LimiteEstadual',
      'Limite Regionais': 'workspace:LimiteRegionais'
    },
    'Infraestrutura': {
      'Malha DER 2024': 'workspace:MalhaDER2024'
    },
    'Sensibilidade Ambiental': {
      'Risco de Fogo INPE': 'workspace:RiscoFogoINPE'
    },
    'Projetos': {
      'Estadualização': {
        'Trechos de Favorabilidade': 'workspace:FavorabilidadeTrechos'
      }
    }
  };

  const sidebar = document.getElementById('sidebar-content');

  for (const grupo in grupos) {
    const grupoDiv = document.createElement('div');
    grupoDiv.className = 'grupo-camadas';
    grupoDiv.innerHTML = `<strong>${grupo}</strong>`;

    const camadas = grupos[grupo];

    for (const sub in camadas) {
      if (typeof camadas[sub] === 'object') {
        const subDiv = document.createElement('div');
        subDiv.className = 'subgrupo-camadas';
        subDiv.innerHTML = `<strong>${sub}</strong>`;

        for (const camada in camadas[sub]) {
          const id = camada.replace(/\s+/g, '_');
          subDiv.innerHTML += `<div class='camada-item'><input type='checkbox' id='${id}'> <label for='${id}'>${camada}</label></div>`;
        }
        grupoDiv.appendChild(subDiv);
      } else {
        const id = sub.replace(/\s+/g, '_');
        grupoDiv.innerHTML += `<div class='camada-item'><input type='checkbox' id='${id}'> <label for='${id}'>${sub}</label></div>`;
      }
    }

    sidebar.appendChild(grupoDiv);
  }

  sidebar.addEventListener('change', function(e) {
    if (e.target.type === 'checkbox') {
      const camadaName = e.target.labels[0].innerText;
      const layerKey = camadaName.replace(/\s+/g, '_');

      if (e.target.checked) {
        layers[layerKey] = L.tileLayer.wms('http://SEU_GEOSERVER/geoserver/ows', {
          layers: `workspace:${layerKey}`,
          format: 'image/png',
          transparent: true
        }).addTo(map);
      } else {
        if (layers[layerKey]) {
          map.removeLayer(layers[layerKey]);
          delete layers[layerKey];
        }
      }
    }
  });
});