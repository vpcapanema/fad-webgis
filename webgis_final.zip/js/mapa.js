const map = L.map('map');

const baseLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(map);

var layers = {};

layers['limiteEstadual'] = L.tileLayer.wms('http://SEU_GEOSERVER/geoserver/ows', {
  layers: 'workspace:LimiteEstadual',
  format: 'image/png',
  transparent: true,
  attribution: 'GeoServer FAD'
}).addTo(map);

map.fitBounds([[-25.5, -53.0], [-19.5, -44.0]]);