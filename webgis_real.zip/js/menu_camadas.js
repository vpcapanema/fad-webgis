document.addEventListener('DOMContentLoaded', () => {
  const camadas = {
    'limiteEstadual': { name: 'workspace:LimiteEstadual', url: 'http://SEU_GEOSERVER/geoserver/ows', title: 'Limite Estadual' },
    'favorabilidadeTrechos': { name: 'workspace:FavorabilidadeTrechos', url: 'http://SEU_GEOSERVER/geoserver/ows', title: 'Trechos de Favorabilidade' },
    'malhaDER': { name: 'workspace:MalhaDER2024', url: 'http://SEU_GEOSERVER/geoserver/ows', title: 'Malha DER 2024' },
    'limiteRegional': { name: 'workspace:LimiteRegionais', url: 'http://SEU_GEOSERVER/geoserver/ows', title: 'Limites Regionais' }
  };

  const sidebarContent = document.getElementById('sidebar-content');

  for (const id in camadas) {
    const div = document.createElement('div');
    div.className = 'camada-item';
    div.innerHTML = `<input type="checkbox" id="${id}" ${id === 'limiteEstadual' ? 'checked' : ''}> <label for="${id}">${camadas[id].title}</label>`;
    sidebarContent.appendChild(div);

    document.getElementById(id).addEventListener('change', function() {
      if (this.checked) {
        layers[id] = L.tileLayer.wms(camadas[id].url, {
          layers: camadas[id].name,
          format: 'image/png',
          transparent: true,
          attribution: 'GeoServer FAD'
        }).addTo(map);
      } else {
        if (layers[id]) {
          map.removeLayer(layers[id]);
          delete layers[id];
        }
      }
    });
  }
});